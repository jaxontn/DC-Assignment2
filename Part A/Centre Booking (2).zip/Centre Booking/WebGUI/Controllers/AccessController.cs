﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RestSharp;
using WebGUI.Models; //NEW

namespace WebGUI.Controllers
{
    public class AccessController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Title = "Admin";

            return View();
        }


        [HttpPost]
        public IActionResult Login(String username, String password)
        {
            /*NEW-------------------------------------------------------------------*/
            RestClient restClient = new RestClient("http://localhost:56447/");
            RestRequest restRequest = new RestRequest("api/Admins", Method.Get);
            RestResponse restResponse = restClient.Execute(restRequest);

            List<Admin> admins = JsonConvert.DeserializeObject<List<Admin>>(restResponse.Content);
            

            //loop through admins to find the admin
            foreach (Admin a in admins)
            {
                if (a.Username == username && a.Password == password)
                {
                    //return RedirectToAction("Index", "Admin");
                    return Ok(admins);
                }
            }
            return NotFound();
            /*----------------------------------------------------------------------*/
        }
        

        [HttpGet]
        public List<Centre> ShowAllCentres()
        {//I changed the return type to List<Centre> because have "500" internal error
            /*NEW-------------------------------------------------------------------*/
            RestClient restClient = new RestClient("http://localhost:56447/");
            RestRequest restRequest = new RestRequest("api/Centres", Method.Get);
            RestResponse restResponse = restClient.Execute(restRequest);
            /*----------------------------------------------------------------------*/

            List<Centre> centres = JsonConvert.DeserializeObject<List<Centre>>(restResponse.Content);

            //return View(centres);
            return centres;
        }


        [HttpGet]
        public List<Booking> ShowCentreBooking(String centreName)
        {
            /*NEW-------------------------------------------------------------------*/
            RestClient restClient = new RestClient("http://localhost:56447/");
            RestRequest restRequest = new RestRequest("api/Bookings", Method.Get);
            RestResponse restResponse = restClient.Execute(restRequest);
            /*----------------------------------------------------------------------*/

            List<Booking> bookings = JsonConvert.DeserializeObject<List<Booking>>(restResponse.Content);

            List<Booking> centreBookings = new List<Booking>();

            foreach (Booking b in bookings)
            {
                String name = (b.CenterName).ToLower();
                String lowerCaseInput = centreName.ToLower();
                if (name.Contains(lowerCaseInput))
                {
                    centreBookings.Add(b);
                }
            }

            return centreBookings;
        }



        [HttpPost]
        public List<Centre> AddCentre(String centreName)
        {
            /*Find number of centres**************************************************/
            RestClient restClient = new RestClient("http://localhost:56447/");
            RestRequest restRequest = new RestRequest("api/Centres", Method.Get);
            RestResponse restResponse = restClient.Execute(restRequest);

            List<Centre> centres = JsonConvert.DeserializeObject<List<Centre>>(restResponse.Content);

            int total = centres.Count;
            /************************************************************************/

            bool foundMatch = false;
            //loop through centres if found centreName
            foreach (Centre c in centres)
            {
                String name = (c.Name).ToLower();
                String lowerCaseInput = centreName.ToLower();


                if (name.Equals(lowerCaseInput))
                {
                    foundMatch = true;
                }
            }

            if(!foundMatch)
            {
                /*NEW-------------------------------------------------------------------*/
                RestClient restClient2 = new RestClient("http://localhost:56447/");
                RestRequest restRequest2 = new RestRequest("api/Centres", Method.Post);
                restRequest2.AddJsonBody(new Centre { Id = total + 1, Name = centreName });
                RestResponse restResponse2 = restClient2.Execute(restRequest2);
                /*----------------------------------------------------------------------*/
            }

            //get the updated centres
            /*NEW-------------------------------------------------------------------*/
            RestClient restClient3 = new RestClient("http://localhost:56447/");
            RestRequest restRequest3 = new RestRequest("api/Centres", Method.Get);
            RestResponse restResponse3 = restClient3.Execute(restRequest3);
            /*----------------------------------------------------------------------*/

            List<Centre> updatedCentres = JsonConvert.DeserializeObject<List<Centre>>(restResponse3.Content);

            return updatedCentres;
        }
    }

}
