﻿namespace WebGUI.Models
{
    public class Centre
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
